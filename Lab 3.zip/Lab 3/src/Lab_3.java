import java.util.Scanner;
public class Lab_3 {
	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	int i = 1;
	int num;
while(i == 1) {
    System.out.printf("Enter a number: ");
    num = input.nextInt();
    if(num > 100 || num < 0) {
    	System.out.println("Sorry, the number you entered is not between 0 and 100");
    	i = 1;
    }
    else {
    	i = 0;
 

    if(num % 2 != 0 && num > 60) {
        System.out.println(num + " is odd and over 60.");
        break;
    }
    else if(num % 2 == 0 && (num > 2 || num < 25) == true) {
    	System.out.printf(num + " is even and less than 25.");
    	break;
    }
    else if(num % 2 == 0 && (num > 26 || num < 60) == true) {
    	System.out.printf("even.");
    	break;
    }
    else if(num % 2 == 0 && (num > 60) == true) {
    	System.out.printf(num + " is even.");
    	break;
    }
    else {
    	System.out.printf(num + " is odd.");
    	break;
    }
    
}

}
}
}
